/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myplanetfood.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Kovid
 */
public class DBConnection {
    private static Connection conn;
    static 
    {
        try 
           {
               Class.forName("oracle.jdbc.OracleDriver");
               conn=DriverManager.getConnection("jdbc:oracle:thin:@//LAPTOP-KVFJ86LO:1521/XE", "xyz", "123");
               System.out.println("connnection successfully");
           }
        catch(Exception ex)
                {
                   JOptionPane.showMessageDialog(null,"error in dbconnection!","ERROR!",JOptionPane.ERROR_MESSAGE);
                   ex.printStackTrace(); 
                }
    }
    public static Connection getconnection()
            {
                return conn;
            }
    public static void closeConnection()
    {
        try
        {
            conn.close();
            System.out.println("system closed");
                    
        }
        catch(SQLException e)
                {
                   JOptionPane.showMessageDialog(null,"error in closing the connection!","ERROR!",JOptionPane.ERROR_MESSAGE);
                   e.printStackTrace();  
                }
    }
    
}
