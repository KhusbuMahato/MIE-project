/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myplanetfood.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import myplanetfood.dbutil.DBConnection;
import myplanetfood.pojo.Product;

/**
 *
 * @author Kovid
 */
public class ProductDao {
    
    
    public static String getNewId ()throws SQLException
    {
        Connection conn=DBConnection.getconnection();
               PreparedStatement  ps= conn.prepareStatement ("select count (*) from product");
               int id =101;
               ResultSet rs=ps.executeQuery();
               if(rs.next())
               {
                   id=id+rs.getInt(1);
                   
               }
               return "P"+id;
    }
    public static boolean addProduct (Product p) throws SQLException
    {
        Connection conn =DBConnection.getconnection();
      
        PreparedStatement ps =conn.prepareStatement("Insert into product values (?,?,?,?,?)" );
                ps.setString(1,p.getProId());
                ps.setString(2,p.getCatId());
                ps.setString(3,p.getProdName());
                ps.setDouble(4,p.getProdPrice());
                ps.setString(5,p.getIsActive());
               int x=ps.executeUpdate();
                return (x>0);
    }
    public static HashMap<String,Product> getProductbyCategory(String catId)throws SQLException
    {
     Connection conn=DBConnection.getconnection();
       PreparedStatement  ps= conn.prepareStatement ("select * from product where catId=?");
       
       HashMap<String, Product>productList =new HashMap<String, Product>();
       
       ps.setString (1,catId);
       ResultSet rs=ps.executeQuery();
       
       while(rs.next())
       {
       Product p=new Product();
       p.setCatId(catId); 
       p.setProId(rs.getString("PRODID"));
       p.setProdName(rs.getString("PRODNAME"));
       p.setProdPrice(rs.getDouble("PRODPRICE"));
       p.setIsActive(rs.getString("active"));
       productList.put(p.getProId(),p);
               
    }
       return productList;
    }
    public static ArrayList<Product> getAllData() throws SQLException{
        Connection conn=DBConnection.getconnection();
        String gry="select * from product";
      Statement  ps= conn.createStatement ();
       ResultSet rs=ps.executeQuery(gry);
       ArrayList<Product> productList=new ArrayList<Product>();
       while(rs.next())
       {
           Product p=new Product();
           p.setCatId(rs.getString("CATID"));
           p.setProId(rs.getString("PRODID"));
           p.setProdName(rs.getString("PRODNAME"));
           p.setProdPrice(rs.getDouble("PRODPRICE"));
           p.setIsActive(rs.getString("active"));
           productList.add(p);
       }
       return productList;
       
    }
    public  static boolean updateProduct(Product p)throws SQLException
    {
        Connection conn =DBConnection.getconnection();
       PreparedStatement ps =conn.prepareStatement("Update product set CATID=?, PRODNAME=?, PRODPRICE=?, ACTIVE=? where PRODID=?" );
        System.out.println(p);
                ps.setString(1,p.getCatId());
                ps.setString(2,p.getProdName());
                ps.setDouble(3,p.getProdPrice());
                ps.setString(4,p.getIsActive());
                ps.setString(5,p.getProId());
               int x=ps.executeUpdate();
                return (x>0);
        
    }
    public static boolean removeProduct(String prodId)throws SQLException
    {
         Connection conn =DBConnection.getconnection();
       PreparedStatement ps =conn.prepareStatement("Update product ACTIVE='N' where PRODID=?" );
        ps.setString(1,prodId);
               int x=ps.executeUpdate();
                return (x>0);
    }
    public static HashMap<String, String> getActiveProductByCategory (String catId) throws SQLException
    {
      Connection conn =DBConnection.getconnection();
      String gry="select PRODNAME,PRODID from product where CATID=? and ACTIVE='y'";
      PreparedStatement ps =conn.prepareStatement(gry);
           ps.setString(1,catId);
          ResultSet rs=ps.executeQuery(gry);
       HashMap<String, String> productList=new HashMap<>();
       while(rs.next()){
           String prodName=rs.getString("PRODNAME");
           String prodId=rs.getString("PRODID");
           productList.put(prodName, prodId);
       }
          return productList;    
         
    }
}