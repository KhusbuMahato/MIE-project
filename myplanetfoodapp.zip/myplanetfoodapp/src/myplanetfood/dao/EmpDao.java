/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myplanetfood.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import myplanetfood.dbutil.DBConnection;
import myplanetfood.pojo.employee;

/**
 *
 * @author Kovid
 */
public class EmpDao {

    
     public static boolean addemploye(employee e) throws SQLException  
    {     Connection conn =DBConnection.getconnection();
      
        PreparedStatement ps =conn.prepareStatement("Insert into employee values (?,?,?,?)" );
       
                ps.setString(1,e.getEmpId());
                ps.setString(2,e.getEmpName());
                ps.setString(3, e.getJob());
                ps.setDouble(4,e.getSalary());
                int result= ps.executeUpdate();
                return(result==1);
                
    }
     public static ArrayList<employee> getalldata() throws SQLException
             {
              Connection conn=DBConnection.getconnection();
              //PreparedStatement ps= conn.prepareStatement ("select* from empolyee");
               String gry="select * from employee";
      Statement  ps= conn.createStatement ();
              ResultSet rs=ps.executeQuery(gry);
              ArrayList<employee>emplist=new ArrayList<employee>();
              while (rs.next())
              {
                  employee e=new employee();
                  e.setEmpId(rs.getString("EMPID"));
                  e.setEmpName(rs.getString("ENAME"));
                  e.setJob(rs.getString("JOB"));
                  e.setSalary(rs.getDouble("SAL"));
                  emplist.add(e);
              }
                      return emplist;
              
             }
     public static ArrayList<String> geteId() throws SQLException
     {Connection conn=DBConnection.getconnection();
              //PreparedStatement ps= conn.prepareStatement ("select* from empolyee");
               String gry="select empid from employee";
      Statement  ps= conn.createStatement ();
              ResultSet rs=ps.executeQuery(gry);
              ArrayList<String>emp=new ArrayList<>();
              while (rs.next())
              {
                  //employee e=new employee();
                  String eId=rs.getString(1);
                  //e.setEmpId(rs.getString("EMPID"));
                  emp.add(eId);
              }
              return emp;
         
     }
     public static HashMap<String , employee> editData(String empid) throws SQLException
     {
      Connection conn=DBConnection.getconnection();
              PreparedStatement ps= conn.prepareStatement ("select * from employee where empid=?");
               //String gry="select ename, job, sal from employee where empid=?";
               //Statement  ps= conn.createStatement ();
             ps.setString(1,empid);
               ResultSet rs=ps.executeQuery();
              
              HashMap<String, employee> emplist=new HashMap<String , employee>();
              while (rs.next())
              {   employee e= new employee();
                  //e.getString("empid");
                  e.setEmpName(rs.getString("ename"));
                  e.setJob(rs.getString("job"));
                  e.setSalary(rs.getDouble("sal"));
                  //String ename=rs.getString("ename");
                  //String job=rs.getString("job");
                  emplist.put(e.getEmpId(),e);
              }
              return emplist;
     
     }
public static boolean updateEmployee(employee ee) throws SQLException
{
              Connection conn=DBConnection.getconnection();
              PreparedStatement ps= conn.prepareStatement ("update employee set ENAME=?, JOB=?, SAL=? where EMPID=?");
              System.out.println(ee);
//ps.setString(4, e.getEmpId());
             
              ps.setString(1, ee.getEmpName());
              ps.setString(2, ee.getJob());
              ps.setDouble(3, ee.getSalary());
              ps.setString(4, ee.getEmpId());
              int x=ps.executeUpdate();
              return (x>0);
}







}
