/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myplanetfood.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import myplanetfood.pojo.user1;
import myplanetfood.dbutil.DBConnection;
import myplanetfood.pojo.RegCashierPojo;

public class UserDao {
    public static String validateUser (user1 user)throws SQLException
    {
       
        Connection conn =DBConnection.getconnection();
       String qry="select username from user1 where userid=? and passward=? and usertype=?";
        PreparedStatement ps =conn.prepareStatement(qry );
                ps.setString(1,user.getUserid());
                ps.setString(2,user.getPassward());
                ps.setString(3,user.getUserType());
                ResultSet rs= ps.executeQuery();
                String username=null;
                if(rs.next())
                {
                    username=rs.getString(1);
                    
                }
                return username;
                
    }
   /* public static HashMap<employee, user1> cashierdata() throws SQLException{
       Connection conn =DBConnection.getconnection();
        PreparedStatement ps1=conn.prepareStatement("insert into user1 values(?,?,?) where empid=?");
        Statement s1=conn.createStatement("select empname from employee where empid=?");
        
    }*/
    public static boolean registeredCashier(RegCashierPojo p) throws SQLException
    {
   
        Connection conn= DBConnection.getconnection();
        PreparedStatement ps=conn.prepareStatement("insert into user1 values(?,?,?,?,?)");
         ps.setString(1, p.getEmpId());
          ps.setString(2, p.getUserId());
          ps.setString(3,p.getCashName());
          ps.setString(4, p.getPassword());
          ps.setString(5, p.getUsertype());
           int  status= ps.executeUpdate();
         return (status>0);
                 
    }
    public String getUserId(String userName) throws SQLException
             {
             Connection conn=DBConnection.getconnection();
         String qry="Select USERID from user1 where USERNAME=?";
         PreparedStatement ps= conn.prepareStatement(qry);
             ps.setString(1, userName);
            ResultSet rs= ps.executeQuery();
             String userId=null;
            if(rs.next())
               
              {
                  userId=rs.getString(1);
              }
                return userId;
             }
}    
    

