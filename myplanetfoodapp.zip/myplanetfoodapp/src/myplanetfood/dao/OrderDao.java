/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myplanetfood.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import myplanetfood.dbutil.DBConnection;
import myplanetfood.pojo.order;
import myplanetfood.pojo.orderDetail;

/**
 *
 * @author Kovid
 */
public class OrderDao {

public static ArrayList<order> getOrderByDate (Date startDate, Date endDate) throws SQLException
{
    Connection conn =DBConnection.getconnection();
       PreparedStatement ps =conn.prepareStatement("select * from orders where ord_date between ? and ?" );
       long ms1=startDate.getTime();
       long ms2=endDate.getTime();
       java.sql.Date sdate=new java.sql.Date(ms1);
       java.sql.Date edate=new java.sql.Date(ms2);
       ps.setDate(1,sdate);
       ps.setDate(2,edate);
       ResultSet rs=ps.executeQuery();
       ArrayList<order> orderList= new ArrayList<order>();
       while(rs.next())
       {
           order obj= new order();
           obj.setOrdId(rs.getString("ordid"));
           java.sql.Date d=rs.getDate("ord_date");
           SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-YYYY");
           String datestr=sdf.format(d);
           obj.setOrdDate(datestr);
           obj.setOrdAmount(rs.getDouble("ord_amount"));
           obj.setGst(rs.getDouble("gst"));
           obj.setGstAmount(rs.getDouble("gst_amount"));
           obj.setGrandTotal(rs.getDouble("grand_total"));
           obj.setDiscount(rs.getDouble("discount"));
           obj.setUserId(rs.getString("userid"));
           orderList.add(obj);
       }
       
       return orderList;
}
 public static String getNewId ()throws SQLException
    {
        Connection conn=DBConnection.getconnection();
               PreparedStatement  ps= conn.prepareStatement ("select count (*) from orders");
               int id =101;
               ResultSet rs=ps.executeQuery();
               if(rs.next())
               {
                   id=id+rs.getInt(1);
                   
               }
               return "od"+id;
    
} 
 public static boolean addOrder (order ord, ArrayList<orderDetail> orderlist) throws SQLException,ParseException 
 {
     Connection conn= DBConnection.getconnection();
     PreparedStatement ps=conn.prepareStatement("insert into orders values(?,?,?,?,?,?,?,?) ");
     ps.setString(1,ord.getOrdId());
     String dateStr=ord.getOrdDate();
     SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
     java.util.Date d1=sdf.parse(dateStr);
     java.sql.Date d2=new java.sql.Date(d1.getTime());
     ps.setDate(2, d2);
     ps.setDouble(3,ord.getGst());
     ps.setDouble(4,ord.getGstAmount());
     ps.setDouble(5,ord.getDiscount());
     ps.setDouble(6,ord.getGrandTotal());
     ps.setString(7,ord.getUserId());
     ps.setDouble(8,ord.getOrdAmount());
     int x=ps.executeUpdate();
     PreparedStatement ps2=conn.prepareStatement("insert into order_detail values(?,?,?,?)");
     int count=0,y;
     for (orderDetail detail:orderlist)
     {
         ps2.setString(1, detail.getOrdId());
         ps2.setString(2, detail.getProdId());
         ps2.setDouble(3, detail.getQuat());
         ps2.setDouble(4, detail.getCost());
         y=ps2.executeUpdate();
                 count =count+y;
     }
     if (x>0&&count==orderlist.size())
         return true;
     else
         return false;
 }
 public static ArrayList<order> getAllOrders() throws SQLException
    {
       Connection conn= DBConnection.getconnection();
        PreparedStatement ps= conn.prepareStatement("Select * from orders ");
         ResultSet rs= ps.executeQuery();
               ArrayList<order> orderList= new ArrayList<order>();
               while(rs.next())
               {
               order ord= new order();
                ord.setOrdId(rs.getString("ord_id"));
                java.sql.Date d= rs.getDate("ord_date");
                  SimpleDateFormat sdf= new SimpleDateFormat("dd-MMM-yyyy");
                  String dateStr= sdf.format(d);
                   ord.setOrdDate(dateStr);
                   ord.setOrdAmount(rs.getDouble("ord_amount"));
                    ord.setGst(rs.getDouble("gst"));
                     ord.setGstAmount(rs.getDouble("gst_amount"));
                      ord.setGrandTotal(rs.getDouble("grand_total"));
                      ord.setDiscount(rs.getDouble("Discount"));
                       ord.setUserId(rs.getString("userid"));
                        orderList.add(ord);
               
               }
                return orderList;
       
    }        
       
    public static ArrayList<order> getAllOrders1() throws SQLException
    {
       Connection conn= DBConnection.getconnection();
        PreparedStatement ps= conn.prepareStatement("Select * from orders");
         ResultSet rs= ps.executeQuery();
               ArrayList<order> orderList= new ArrayList<order>();
               while(rs.next())
               {
               order ord= new order();
                ord.setOrdId(rs.getString("ord_id"));
                java.sql.Date d= rs.getDate("ord_date");
                  SimpleDateFormat sdf= new SimpleDateFormat("dd-MMM-yyyy");
                  String dateStr= sdf.format(d);
                   ord.setOrdDate(dateStr);
                   ord.setOrdAmount(rs.getDouble("ord_amount"));
                    ord.setGst(rs.getDouble("gst"));
                     ord.setGstAmount(rs.getDouble("gst_amount"));
                      ord.setGrandTotal(rs.getDouble("grand_total"));
                      ord.setDiscount(rs.getDouble("Discount"));
                       ord.setUserId(rs.getString("userid"));
                        orderList.add(ord);
               
               }
                return orderList;
       
    }  
      public static ArrayList<order> getAllOrdersByCashier( String userId) throws SQLException
    {
       Connection conn= DBConnection.getconnection();
        PreparedStatement ps= conn.prepareStatement("Select * from orders where USERID=? ");
         ps.setString(1, userId);
         ResultSet rs= ps.executeQuery();
               ArrayList<order> orderList= new ArrayList<order>();
               while(rs.next())
               {
               order ord= new order();
                ord.setOrdId(rs.getString("ord_id"));
                java.sql.Date d= rs.getDate("ord_date");
                  SimpleDateFormat sdf= new SimpleDateFormat("dd-MMM-yyyy");
                  String dateStr= sdf.format(d);
                   ord.setOrdDate(dateStr);
                   ord.setOrdAmount(rs.getDouble("ord_amount"));
                    ord.setGst(rs.getDouble("gst"));
                     ord.setGstAmount(rs.getDouble("gst_amount"));
                      ord.setGrandTotal(rs.getDouble("grand_total"));
                      ord.setDiscount(rs.getDouble("Discount"));
                       ord.setUserId(rs.getString("userid"));
                        orderList.add(ord);
               
               }
                return orderList;
       
    }     
    
}
