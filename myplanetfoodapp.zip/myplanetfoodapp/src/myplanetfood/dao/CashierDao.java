/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myplanetfood.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import myplanetfood.dbutil.DBConnection;
import myplanetfood.pojo.Product;
import myplanetfood.pojo.RegCashierPojo;

/**
 *
 * @author Kovid
 */
public class CashierDao {
      public static HashMap<String, String> getCashierEmpId() throws SQLException
    {
     Connection conn=DBConnection.getconnection();
      PreparedStatement ps=conn.prepareStatement("select EMPID,ENAME from employee where JOB='cashier'");
     ResultSet rs= ps.executeQuery();
      HashMap <String, String> getCashierId= new HashMap<>();
      while (rs.next())
      {
       
        String empId= rs.getString("EMPID");
          String CashName= rs.getString("ENAME");
                      getCashierId.put(empId, CashName);
      }
       return getCashierId;
}
    public static boolean registeredCashier(RegCashierPojo p) throws SQLException
    {
   
        Connection conn= DBConnection.getconnection();
        PreparedStatement ps=conn.prepareStatement("insert into user1 values(?,?,?,?,?)");
         ps.setString(1, p.getEmpId());
          ps.setString(2, p.getUserId());
          ps.setString(3,p.getCashName());
          ps.setString(4, p.getPassword());
          ps.setString(5, p.getUsertype());
           int  status= ps.executeUpdate();
         return (status>0);
                 
    }
         
   public static ArrayList<RegCashierPojo> searchCashier(String EmpNo) throws SQLException
    {
     
         PreparedStatement ps=DBConnection.getconnection().prepareStatement("select USERID,USERNAME,EMPID from user1 where USERID=?");
            ps.setString(1, EmpNo);
             ResultSet rs= ps.executeQuery();
              ArrayList <RegCashierPojo> searchEmp= new ArrayList<>();
                     
              while(rs.next())
              {
                RegCashierPojo e= new RegCashierPojo();
               
                 e.setUserId(rs.getString("USERID"));
                  e.setCashName(rs.getString("USERNAME"));
                  e.setEmpId(rs.getString("EMPID"));
                  searchEmp.add(e);
              }
               return searchEmp;
    }
     public static boolean deleteCashier(String empno) throws SQLException
    {
     PreparedStatement ps=DBConnection.getconnection().prepareStatement("delete from user1 where USERID=?");
      ps.setString(1, empno);
        int result=ps.executeUpdate();
        return(result==1);
   
    }
      public static ArrayList< Product> getAllCategoryid(String catId) throws SQLException
    {
       
  PreparedStatement ps=DBConnection.getconnection().prepareStatement("select *from product where CAT_ID=?");
            ps.setString(1, catId);
           ArrayList <Product> productList= new ArrayList<Product>();
            ResultSet rs=ps.executeQuery();
           while(rs.next())
           {
      Product p= new Product();
         p.setProId(rs.getString("PROD_ID"));
         p.setCatId(rs.getString("CAT_ID"));                    
         p.setProdName(rs.getString("PROD_NAME"));
         p.setProdPrice(rs.getDouble("PROD_PRICE"));
         p.setIsActive(rs.getString("ACTIVE"));
            productList.add(p);
           }
           
           return productList;
 
   
}
      public static ArrayList <Product> getAllData(String catId) throws SQLException
 {
     Connection conn= DBConnection.getconnection();
      String qry= "select * from product where CAT_ID=?";
      Statement st=conn.createStatement();
         ResultSet rs= st.executeQuery(qry);
           ArrayList <Product> productList= new ArrayList<Product>();
           while(rs.next())
           {
      Product p= new Product();
         p.setProId(rs.getString("PROD_ID"));
         p.setCatId(rs.getString("CAT_ID"));
         p.setProdName(rs.getString("PROD_NAME"));
         p.setProdPrice(rs.getDouble("PROD_PRICE"));
         p.setIsActive(rs.getString("ACTIVE"));
            productList.add(p);
           }
           
           return productList;
 }
      public static int validateCashier( String empId) throws SQLException
      {
         int x=0;
      PreparedStatement ps=DBConnection.getconnection().prepareStatement("select USERNAME from user1 where EMPID=?");
            ps.setString(1, empId);
             ResultSet rs= ps.executeQuery();
             while(rs.next())
             {
             String  name=rs.getString("USERNAME");
                 x++;
                   return x;
             }
              return x;
      }
}
