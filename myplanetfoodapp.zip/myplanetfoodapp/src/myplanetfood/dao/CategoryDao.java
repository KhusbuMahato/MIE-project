/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myplanetfood.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale.Category;
import myplanetfood.dbutil.DBConnection;
import myplanetfood.pojo.category;

/**
 *
 * @author Kovid
 */
public class CategoryDao {
    public static HashMap<String,String> getAllCategoryId() throws SQLException
    {
       Connection conn=DBConnection.getconnection();
       Statement st=conn.createStatement();
       ResultSet rs=st.executeQuery("select CatName, catId from category");
       HashMap<String, String>category =new HashMap<>();
       while(rs.next())
       {
           String catName=rs.getString(1);
           String catId=rs.getString(2);
           category.put(catName,catId);
       }
       return category;
    }
    public static String getNewId ()throws SQLException
    {
        Connection conn=DBConnection.getconnection();
               PreparedStatement  ps= conn.prepareStatement ("select count (*) from category");
               int id =101;
               ResultSet rs=ps.executeQuery();
               if(rs.next())
               {
                   id=id+rs.getInt(1);
                   
               }
               return "c"+id;
    
}
public static boolean addCategory (category c) throws SQLException
    {
        Connection conn =DBConnection.getconnection();
      
        PreparedStatement ps =conn.prepareStatement("Insert into category values (?,?)" );
                
                ps.setString(1,c.getCatId());
                ps.setString(2,c.getCatName());
               
               int x=ps.executeUpdate();
                return (x>0);
    }
public static ArrayList<category> viewCatId() throws SQLException
     {
      Connection conn=DBConnection.getconnection();
         
         Statement st= conn.createStatement();
         
          ResultSet rs= st.executeQuery("select * from category");
         
           ArrayList <category> Categories= new ArrayList<>();
           
            while(rs.next())
                    {
                         category c= new category();
                         c.setCatId(rs.getString("CATID"));
                          c.setCatName(rs.getString("CATNAME"));
                            Categories.add(c);
                            System.out.println("11");
                    }
           return Categories;
     }

}
