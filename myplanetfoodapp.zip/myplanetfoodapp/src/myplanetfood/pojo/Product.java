/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myplanetfood.pojo;
public class Product {

    @Override
    public String toString() {
        return "Product{" + "proId=" + proId + ", catId=" + catId + ", prodName=" + prodName + ", prodPrice=" + prodPrice + ", isActive=" + isActive + '}';
    }
    
    private String proId;
    private String catId;
    private String prodName;
    private Double prodPrice;
    private String isActive;

    public String getProId() {
        return proId;
    }

    public void setProId(String proId) {
        this.proId = proId;
    }

    public String getCatId() {
        return catId;
    }

    public void setCatId(String catId) {
        this.catId = catId;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public Double getProdPrice() {
        return prodPrice;
    }

    public void setProdPrice(Double prodPrice) {
        this.prodPrice = prodPrice;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }
    
    
    
    
}
