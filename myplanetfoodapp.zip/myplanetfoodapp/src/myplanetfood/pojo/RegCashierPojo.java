/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myplanetfood.pojo;

/**
 *
 * @author Kovid
 */
public class RegCashierPojo {

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String UserId) {
        this.UserId = UserId;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getUsertype() {
        return Usertype;
    }

    public void setUsertype(String Usertype) {
        this.Usertype = Usertype;
    }

    public String getCashName() {
        return CashName;
    }

    public void setCashName(String CashName) {
        this.CashName = CashName;
    }

    public String getEmpId() {
        return EmpId;
    }

    public void setEmpId(String EmpId) {
        this.EmpId = EmpId;
    }
    private String UserId;
    private String Password;
    private String Usertype;
    private String CashName;
    private String EmpId;
    
    
}
